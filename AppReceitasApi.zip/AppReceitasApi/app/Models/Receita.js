'use strict'

const Model = use('Model')
const Env = use('Env')

class Receita extends Model {
    
}

module.exports = Receita
